/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.insalyon.dasi.predictif.services;

import com.google.maps.model.LatLng;
import fr.insalyon.dasi.predictif.exception.MediumException;
import static fr.insalyon.dasi.predictif.exception.MediumException.AUCUN_RESULTAT_MEDIUM;
import fr.insalyon.dasi.predictif.exception.ConsultationException;
import static fr.insalyon.dasi.predictif.exception.ConsultationException.AUCUN_RESULTAT_CONSULTATION;
import fr.insalyon.dasi.predictif.exception.PersonneException;
import static fr.insalyon.dasi.predictif.exception.PersonneException.AUCUN_RESULTAT_PERSONNE;
import static fr.insalyon.dasi.predictif.exception.PersonneException.IDENTIFIANTS_INVALIDES;
import fr.insalyon.dasi.predictif.models.Astrologue;
import fr.insalyon.dasi.predictif.models.Cartomancien;
import fr.insalyon.dasi.predictif.models.Client;
import fr.insalyon.dasi.predictif.models.Consultation;
import fr.insalyon.dasi.predictif.models.Employe;
import fr.insalyon.dasi.predictif.models.Medium;
import fr.insalyon.dasi.predictif.models.Personne;
import fr.insalyon.dasi.predictif.models.ProfilAstral;
import fr.insalyon.dasi.predictif.models.Spirite;
import fr.insalyon.dasi.predictif.persistence.ClientDao;
import fr.insalyon.dasi.predictif.persistence.ConsultationDao;
import fr.insalyon.dasi.predictif.persistence.EmployeDao;
import fr.insalyon.dasi.predictif.persistence.JpaUtil;
import fr.insalyon.dasi.predictif.persistence.MediumDao;
import fr.insalyon.dasi.predictif.persistence.PersonneDao;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author lfaustmann
 */
public class Services {
    public static Client inscrireClient(Client client)
    {
        try{    
            PersonneDao personneDao = new PersonneDao();
            JpaUtil.creerContextePersistance();
            JpaUtil.ouvrirTransaction();
            
            ProfilAstral profilAstral = creerProfilAstral(client);
            client.setProfilAstral(profilAstral);
            
            LatLng coordsClient = GeoNetApi.getLatLng(client.getAdressePostale());
            if(coordsClient == null)
            {
                throw new NullPointerException("L'adresse postale est incorrecte");
            }
            client.setLatitude(coordsClient.lat);
            client.setLongitude(coordsClient.lng);
            
            personneDao.create(client);

            JpaUtil.validerTransaction();
            Message.envoyerMail("contact@predict.if", client.getEmail(), "Bienvenue chez PREDICT'IF", "Bonjour " + client.getPrenom() + ", nous vous confirmons votre inscription au service PREDICT'IF. Rendez-vous vite sur notre site pour consulter votre profil astrologique et profiter des dons incroyables de nos mediums");
            System.out.println("Trace : succès inscription du client : " + client);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            JpaUtil.annulerTransaction();
            Message.envoyerMail("contact@predict.if", client.getEmail(), "Echec de l'inscription chez PREDICT'IF", "Bonjour " + client.getPrenom() + ", votre inscription au service Predict'IF a malencontreusement échoué... Merci de recommencer ultérieurement.");
            System.out.println("Trace : échec inscription du client");
            client = null;
        }
        finally {
            JpaUtil.fermerContextePersistance();        
        }
        return client;
    }
    
    public static Personne connexionPersonne(String email, String motDePasse) throws PersonneException
    {
        Personne personneConnecte = null;        
        try{  
            PersonneDao personneDao = new PersonneDao();
            JpaUtil.creerContextePersistance();            
            personneConnecte =  personneDao.findByEmail(email);
            
            if(personneConnecte == null | !personneConnecte.getMotDePasse().equals(motDePasse))
            {
                throw new PersonneException(IDENTIFIANTS_INVALIDES);
            }
            
            System.out.println("Trace : succès connexion de la personne : " + personneConnecte);
        }
        catch(PersonneException ex){
            ex.printStackTrace();
            System.out.println("Trace : Identifiants invalides"); 
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Trace : échec connexion de la personne");                     
        }
        finally {
        JpaUtil.fermerContextePersistance();
        }
        return personneConnecte;
    }
    
    public static void initData(){
        List<String> spritesSupports = new ArrayList();
        spritesSupports.add("Boule de cristal");
        spritesSupports.add("Oreilles de lapin");
        spritesSupports.add("Marc de café");
        Spirite spirite = new Spirite(spritesSupports, "Josette", 'F', "Josette la rossette");
        
        Cartomancien cartomancien = new Cartomancien("Irma", 'F', "Je vais te manger l'oreille");
        
        Astrologue astrologue = new Astrologue("ESA", 2002, "Thomas Pesquet", 'H', "Pour toi je décroche les étoiles");
        
        creerUnMedium(spirite);
        creerUnMedium(cartomancien);
        creerUnMedium(astrologue);
        
        // Création des employés
        Employe employe1 = new Employe("Martin", "Camille", "martion.camille@gmail.com", 'F', "123456789", "0783382317", Boolean.TRUE);
        Employe employe2 = new Employe("Conte", "Justin", "justin.conte@gmail.com", 'H', "123456789", "0769696969", Boolean.TRUE);
        Employe employe3 = new Employe("Peaumo", "Theo", "theo.peaumo@gmail.com", 'H', "123456789", "0769696969", Boolean.TRUE);
        
        creerUnEmploye(employe1);
        creerUnEmploye(employe2);
        creerUnEmploye(employe3);
    }
     
    public static Consultation creerConsultation(Client client, Medium medium){
        Consultation consultation = null;
        try{    
            ConsultationDao consultationDao = new ConsultationDao();
            EmployeDao employeDao = new EmployeDao();
            PersonneDao personneDao = new PersonneDao();
            JpaUtil.creerContextePersistance();
            JpaUtil.ouvrirTransaction();

            Employe employe = employeDao.findEmployeDisponible(medium.getGenre());
            if(employe == null)
            {
                throw new PersonneException(AUCUN_RESULTAT_PERSONNE);
            }
            
            consultation = new Consultation(employe, client, medium);
            consultationDao.create(consultation);
            
            employe.setEstDisponible(Boolean.FALSE);
            personneDao.update(employe);
                
            JpaUtil.validerTransaction();
            Message.envoyerNotification(employe.getTelephone(), "Bonjour " + consultation.getEmploye().getPrenom() + ". Consultation requise pour " + (client.getGenre() == 'H' ? "M" : "Mme") + " " + client.getPrenom() + " " + client.getNom() + ". Médium à incarner : " + (medium.getGenre() == 'H' ? "M" : "Mme") + " " + medium.getDenomination());
            System.out.println("Trace : succès création consultation : " + consultation);
        }
        catch(PersonneException ex){
            ex.printStackTrace();
            JpaUtil.annulerTransaction();
            System.out.println("Trace : Aucun employé n'est disponible"); 
        }
        catch (Exception ex) {
            ex.printStackTrace();
            JpaUtil.annulerTransaction();
            System.out.println("Trace : échec création consultation");            
        }
        finally {
            JpaUtil.fermerContextePersistance();        
        }
        return consultation;
    }
    
    public static Consultation getConsultationEnAttente(Employe employe) {
        Consultation consultationEnAttente = null;
        try{  
            ConsultationDao consultationDao = new ConsultationDao();
            JpaUtil.creerContextePersistance(); 
            
            consultationEnAttente = consultationDao.getConsultationEnAttente(employe);
            if(consultationEnAttente == null)
            {
                throw new ConsultationException(AUCUN_RESULTAT_CONSULTATION);
            }
            System.out.println("Trace : succès de la récupération de la consultation en cours : " + consultationEnAttente);
        }
        catch(ConsultationException ex){
            ex.printStackTrace();
            System.out.println("Trace : Aucune consultation en attente"); 
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Trace : échec de la récupération de la consultation en cours");            
        }
        finally {  
            JpaUtil.fermerContextePersistance(); 
        }
        return consultationEnAttente;
    }
    
    public static void commencerConsultation(Long idConsultation){
        try{    
            ConsultationDao consultationDao = new ConsultationDao();
            JpaUtil.creerContextePersistance();
            JpaUtil.ouvrirTransaction();            
            
            Consultation consultation = consultationDao.findById(idConsultation); 
            if(consultation == null)
            {
                throw new ConsultationException(AUCUN_RESULTAT_CONSULTATION);
            }
            
            consultation.setDateDebut(new Date());
            consultationDao.update(consultation);  
            
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM 'à' HH'h'mm");

            JpaUtil.validerTransaction();
            Message.envoyerNotification(consultation.getClient().getTelephone(), "Bonjour " + consultation.getClient().getPrenom() + ". J'ai bien reçu votre demande de consultation du " + dateFormat.format(consultation.getDateDebut()) + ". Vous pouvez dès à présent me contacter au " + consultation.getEmploye().getTelephone() + ". A tout de suite ! Médiumiquement vôtre, " + (consultation.getMedium().getGenre() == 'H' ? "M" : "Mme") + " " + consultation.getMedium().getDenomination());
            System.out.println("Trace : succès du début de la consultation : "+ consultation);
        }
        catch(ConsultationException ex){
            ex.printStackTrace();
            JpaUtil.annulerTransaction();
            System.out.println("Trace : Consultation inconnue"); 
        }
        catch (Exception ex) {
            ex.printStackTrace();
            JpaUtil.annulerTransaction();
            System.out.println("Trace : échec du début de la consultation");            
        }
        finally {
            JpaUtil.fermerContextePersistance();        
        }
    }
    
    public static  Boolean validerConsultation(Long idConsultation, String commentaire){
        Boolean aEteChange = false;
        try{    
            ConsultationDao consultationDao = new ConsultationDao();
            PersonneDao personneDao = new PersonneDao();
            JpaUtil.creerContextePersistance();
            JpaUtil.ouvrirTransaction();            
            
            Consultation consultation = consultationDao.findById(idConsultation); 
            if(consultation == null)
            {
                throw new ConsultationException(AUCUN_RESULTAT_CONSULTATION);
            }
            consultation.setDateFin(new Date());
            consultation.setCommentaire(commentaire);
            consultationDao.update(consultation);            
            
            Employe employe = consultation.getEmploye();
            employe.setEstDisponible(Boolean.TRUE);
            personneDao.update(employe);
            
            aEteChange = true;

            JpaUtil.validerTransaction();
            System.out.println("Trace : succès validation de la consultation : "+consultation);
        }
        catch(ConsultationException ex){
            ex.printStackTrace();
            JpaUtil.annulerTransaction();
            System.out.println("Trace : Consultation inconnue"); 
        }
        catch (Exception ex) {
            ex.printStackTrace();
            JpaUtil.annulerTransaction();
            System.out.println("Trace : échec validation de la consultation");            
        }
        finally {
            JpaUtil.fermerContextePersistance();        
        }
        return aEteChange;
    }
    
    public static List<Medium> getMediums(){
        List<Medium> mediums = null;        
        try{  
            MediumDao mediumDao = new MediumDao();
            JpaUtil.creerContextePersistance();            
            mediums =  mediumDao.getMediums();
            if(mediums == null)
            {
                throw new MediumException(AUCUN_RESULTAT_MEDIUM);
            }
            System.out.println("Trace : succès récupération des médiums");
        }
        catch(MediumException ex){
            ex.printStackTrace();
            System.out.println("Trace : Aucun medium existant"); 
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Trace : échec récupération des médiums");                     
        }
        finally {
        JpaUtil.fermerContextePersistance();
        }
        return mediums;
    }   
    
    public static Client getClientById(Long idClient) {
        Client client = null;        
        try{  
            PersonneDao personneDao = new PersonneDao();
            JpaUtil.creerContextePersistance();            
            Personne personne =  personneDao.findById(idClient);
            
            if (personne instanceof Client)
            {
                client = (Client) personne;
            }
            else {
                throw new PersonneException(AUCUN_RESULTAT_PERSONNE);
            }
            
            System.out.println("Trace : succès récupération du client : " + client);
        }
        catch(PersonneException ex){
            ex.printStackTrace();
            System.out.println("Trace : Client inconnu"); 
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Trace : échec récupération du client " );                     
        }
        finally {
        JpaUtil.fermerContextePersistance();
        }
        return client;
    }
    
    public static Employe getEmployeById(Long idEmploye) {
        Employe employe = null;        
        try{  
            PersonneDao personneDao = new PersonneDao();
            JpaUtil.creerContextePersistance();            
            Personne personne =  personneDao.findById(idEmploye);
            
            if (personne instanceof Employe)
            {
                employe = (Employe) personne;
            }
            else {
                throw new PersonneException(AUCUN_RESULTAT_PERSONNE);
            }
            
            System.out.println("Trace : succès récupération de l'employe : " + employe);
        }
        catch(PersonneException ex){
            ex.printStackTrace();
            System.out.println("Trace : Employé inconnu"); 
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Trace : échec récupération de l'employe ");                     
        }
        finally {
        JpaUtil.fermerContextePersistance();
        }
        return employe;
    }
    
    public static Medium getMediumById(Long idMedium) {
        Medium medium = null;        
        try{  
            MediumDao mediumDao = new MediumDao();
            JpaUtil.creerContextePersistance();            
            medium =  mediumDao.findById(idMedium);
            if(medium == null)
            {
                throw new MediumException(AUCUN_RESULTAT_MEDIUM);
            }
            
            System.out.println("Trace : succès récupération du medium : " + medium);
        }
        catch(MediumException ex){
            ex.printStackTrace();
            System.out.println("Trace : Medium inconnu"); 
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Trace : échec récupération du medium ");                     
        }
        finally {
        JpaUtil.fermerContextePersistance();
        }
        return medium;
    }
    
    public static List<Medium> getMediumsTopX(Integer x) {
        List<Medium> mediums = null;        
        try{  
            MediumDao mediumDao = new MediumDao();
            JpaUtil.creerContextePersistance();            
            mediums =  mediumDao.findTopX(x);
            if(mediums == null)
            {
                throw new MediumException((AUCUN_RESULTAT_MEDIUM));
            }
            
            System.out.println("Trace : succès récupération du TopX des médiums : " + mediums);
        }
        catch(MediumException ex){
            ex.printStackTrace();
            System.out.println("Trace : Aucun medium existant"); 
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Trace : échec récupération du du TopX des médiums " );                     
        }
        finally {
        JpaUtil.fermerContextePersistance();
        }
        return mediums;
    }
    
    public static List<Client> getClients() {
        List<Client> clients = null;        
        try{  
            ClientDao clientDao = new ClientDao();
            JpaUtil.creerContextePersistance();            
            clients =  clientDao.getClients();
            
            if(clients == null)
            {
                throw new PersonneException(AUCUN_RESULTAT_PERSONNE);
            }
            
            System.out.println("Trace : succès récupération des clients");
        }
        catch(PersonneException ex){
            ex.printStackTrace();
            System.out.println("Trace : Aucun client existant"); 
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Trace : échec récupération des clients");                     
        }
        finally {
        JpaUtil.fermerContextePersistance();
        }
        return clients;
    }
    
    public static List<Employe> getEmployes() {
        List<Employe> employes = null;        
        try{  
            EmployeDao employeDao = new EmployeDao();
            JpaUtil.creerContextePersistance();            
            employes =  employeDao.getEmployes();
            
            if(employes == null)
            {
                throw new PersonneException(AUCUN_RESULTAT_PERSONNE);
            }
            
            System.out.println("Trace : succès récupération des employes");
        }
        catch(PersonneException ex){
            ex.printStackTrace();
            System.out.println("Trace : Aucun employé existant"); 
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Trace : échec récupération des employes");                     
        }
        finally {
        JpaUtil.fermerContextePersistance();
        }
        return employes;
    }
    
    public static List<String> getPredictions(Client client, int amour, int sante, int travail) {
        List<String> predictions = null;
        try{  
            AstroNetApi astroApi = new AstroNetApi();
            predictions = astroApi.getPredictions(client.getProfilAstral().getCouleurBonheur(), client.getProfilAstral().getAnimalTotem(), amour, sante, travail);
            System.out.println("Trace : succès récupération des prédictions ");
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Trace : échec récupération des prédictions ");                     
        }
        return predictions;
    }
    
    private static Medium creerUnMedium(Medium medium){
        try{    
            MediumDao mediumDao = new MediumDao();
            JpaUtil.creerContextePersistance();
            JpaUtil.ouvrirTransaction();
            
            mediumDao.create(medium);

            JpaUtil.validerTransaction();
            System.out.println("Trace : succès création medium");
        }
        catch (Exception ex) {
            ex.printStackTrace();
            JpaUtil.annulerTransaction();
            System.out.println("Trace : échec création medium");            
        }
        finally {
            JpaUtil.fermerContextePersistance();        
        }
        return medium;
    }
    
    private static Employe creerUnEmploye(Employe employe){
        try{    
            PersonneDao personneDao = new PersonneDao();
            JpaUtil.creerContextePersistance();
            JpaUtil.ouvrirTransaction();
            
            personneDao.create(employe);

            JpaUtil.validerTransaction();
            System.out.println("Trace : succès création employe");
        }
        catch (Exception ex) {
            ex.printStackTrace();
            JpaUtil.annulerTransaction();
            System.out.println("Trace : échec création employe");            
        }
        finally {
            JpaUtil.fermerContextePersistance();        
        }
        return employe;
    }
    
    private static ProfilAstral creerProfilAstral(Client client) throws IOException{
        ProfilAstral profilcreate;
        try{    
            AstroNetApi astroApi = new AstroNetApi();
            List<String> profil = astroApi.getProfil(client.getPrenom(), client.getDateDeNaissance());
            String signeZodiaque = profil.get(0);
            String signeChinois = profil.get(1);
            String couleur = profil.get(2);
            String animal = profil.get(3);
            
            profilcreate =  new ProfilAstral(signeZodiaque, signeChinois, couleur, animal);
            System.out.println("Trace : succès création profil astrale");
        }
        catch (Exception ex) {
            ex.printStackTrace();
            profilcreate = null;
        }
        return profilcreate;
    }
}
